#!/bin/bash
# create multiresolution windows icon
ICON_SRC=../../src/qt/res/icons/helveticacoins.png
ICON_DST=../../src/qt/res/icons/helveticacoins.ico
convert ${ICON_SRC} -resize 16x16 helveticacoins-16.png
convert ${ICON_SRC} -resize 32x32 helveticacoins-32.png
convert ${ICON_SRC} -resize 48x48 helveticacoins-48.png
convert helveticacoins-16.png helveticacoins-32.png helveticacoins-48.png ${ICON_DST}

